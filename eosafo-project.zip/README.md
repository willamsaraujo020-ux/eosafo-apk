# EOSAFO

Aplicativo Android de apoio aos estudos para concursos públicos.

## Gerar APK
O GitHub Actions compila automaticamente o APK quando houver push na branch principal. Também é possível iniciar manualmente em **Actions → Gerar APK EOSAFO → Run workflow**. O arquivo fica em **Artifacts → EOSAFO-apk**.

O APK de depuração gerado é `app-debug.apk`.
